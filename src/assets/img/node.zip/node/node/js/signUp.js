let collectedData = [];
let personType = '';

function selectPersonType(type) {
    personType = type;
    showBlock(2);
}

function showBlock(blockNumber) {
    document.getElementById('block1').classList.add('hidden');
    document.getElementById('block2').classList.add('hidden');
    document.getElementById('block3').classList.add('hidden');
    document.getElementById('block' + blockNumber).classList.remove('hidden');
}

// Updated event listener for checkboxes in Block 2
document.getElementById('form2').addEventListener('change', function() {
    const checkboxes = document.querySelectorAll('#form2 .form-check-input');
    let atLeastOneChecked = false;
    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            atLeastOneChecked = true;
        }
    });
    document.getElementById('nextBtn2').disabled = !atLeastOneChecked;
});

// Updated event listener for checkboxes in Block 3
const checkboxes3 = document.querySelectorAll('#block3 .form-check-input');
checkboxes3.forEach(checkbox => {
    checkbox.addEventListener('change', function() {
        let atLeastOneChecked = false;
        checkboxes3.forEach(cb => {
            if (cb.checked) {
                atLeastOneChecked = true;
            }
        });
        document.getElementById('nextBtn3').disabled = !atLeastOneChecked;
    });
});

// Modal window
const modal = document.getElementById("myModal");

function openModal() {
    modal.style.display = "block";
}

function closeModal() {
    modal.style.display = "none";
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

// Handle selection of format buttons
const formatButtons = document.querySelectorAll('.btn-primary[data-format]');
const contactButtons = document.querySelectorAll('.btn_massenger');

let selectedFormat = '';
let selectedContact = '';

formatButtons.forEach(button => {
    button.addEventListener('click', function() {
        formatButtons.forEach(btn => btn.classList.remove('selected'));
        this.classList.add('selected');
        selectedFormat = this.getAttribute('data-format');
        validateForm();
    });
});

contactButtons.forEach(button => {
    button.addEventListener('click', function() {
        contactButtons.forEach(btn => btn.classList.remove('selected'));
        this.classList.add('selected');
        selectedContact = this.getAttribute('data-contact');
        validateForm();
    });
});

function validateForm() {
    const name = document.getElementById('name').value.trim();
    const surname = document.getElementById('surname').value.trim();
    const phone = document.getElementById('phone').value.trim();

    if (selectedFormat && name && surname && phone && selectedContact) {
        document.getElementById('submitBtn').disabled = false;
    } else {
        document.getElementById('submitBtn').disabled = true;
    }
}

document.getElementById('name').addEventListener('input', validateForm);
document.getElementById('surname').addEventListener('input', validateForm);
document.getElementById('phone').addEventListener('input', validateForm);

function handleNextBlock3() {
    const collapsibleButtons = document.querySelectorAll('.collapsible');
    collapsibleButtons.forEach(button => {
        button.classList.add('disabled');
    });
    openModal();
}

function submitForm() {
    const name = document.getElementById('name').value.trim();
    const surname = document.getElementById('surname').value.trim();
    const phone = document.getElementById('phone').value.trim();

    console.log('Name:', name);
    console.log('Surname:', surname);
    console.log('Phone:', phone);
    console.log('Selected Format:', selectedFormat);
    console.log('Selected Contact:', selectedContact);

    collectedData = [
        { "Ім'я": name, "Прізвище": surname, "Номер телефону": phone, "Формат": selectedFormat, "Зв'язок": selectedContact, "Оберіть для кого ви шукаєте психолога": personType },
        ...collectBlockData()
    ];

    console.log('Collected Data:', collectedData);

    const message = `Новий клієнт:\n\n${formatMessage(collectedData)}`;

    console.log('Message:', message);

    axios.post(`https://api.telegram.org/bot7422150513:AAF54MNA-R81ID9TIXf9C0QIWj8cFmFWwNo/sendMessage`, {
        chat_id: '7407341685',
        text: message,
        parse_mode: 'Markdown'
    })
    .then(response => {
        alert('Дані відправлені. Дякуємо');
        console.log('Success:', response.data);
    })
    .catch(error => {
        alert('Помилка відправки даних');
        console.error('Error:', error);
    });

    modal.style.display = "none";
}

function collectBlockData() {
    let blockData = [];
    // Collect data from Block 2
    const stateCheckboxes = document.querySelectorAll('#form2 .form-check-input');
    stateCheckboxes.forEach(checkbox => {
        if (checkbox.checked) {
            blockData.push({ "Чи перебуваєте ви останнім часом в якихось із цих станів?": checkbox.labels[0].innerText });
        }
    });
    // Collect data from Block 3
    const block3Checkboxes = document.querySelectorAll('#block3 .form-check-input');
    block3Checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            blockData.push({ "Оберіть теми, з якими ви б хотіли попрацювати": checkbox.labels[0].innerText });
        }
    });
    return blockData;
}

function formatMessage(data) {
    let message = '';
    data.forEach(item => {
        for (const key in item) {
            message += `*${key}*: ${item[key]}\n`;
        }
        message += '\n';
    });
    return message;
}
