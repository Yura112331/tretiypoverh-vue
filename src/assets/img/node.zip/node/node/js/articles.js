function showMore(button) {
    var card = button.closest('.card1');
    var additionalContent = card.querySelector('.additional-content');
    var showMoreBtn = card.querySelector('.show-more-btn');
    var hideBtn = card.querySelector('.hide-btn');
    var fadeOut = card.querySelector('.fade-out');

    additionalContent.style.display = "block";
    fadeOut.style.display = "none";
    showMoreBtn.style.display = "none";
    hideBtn.style.display = "block";
}

function hideContent(button) {
    var card = button.closest('.card1');
    var additionalContent = card.querySelector('.additional-content');
    var showMoreBtn = card.querySelector('.show-more-btn');
    var hideBtn = card.querySelector('.hide-btn');
    var fadeOut = card.querySelector('.fade-out');

    additionalContent.style.display = "none";
    fadeOut.style.display = "block";
    showMoreBtn.style.display = "block";
    hideBtn.style.display = "none";
}