let lastScrollY = window.scrollY;
const header = document.getElementById("header");

window.addEventListener("scroll", () => {
  if (window.scrollY > lastScrollY) {
    // Scrolling down
    header.classList.add("hide");
    header.classList.remove("show");
  } else {
    // Scrolling up
    header.classList.add("show");
    header.classList.remove("hide");
  }
  lastScrollY = window.scrollY;
});

function toggleAnswer(element) {
  var answer = element.nextElementSibling;
  var arrow = element.querySelector(".arrow");
  var isActive = element.classList.contains("active");
  document.querySelectorAll(".question").forEach(function (q) {
      q.classList.remove("active");
      q.nextElementSibling.style.maxHeight = null;
      q.querySelector(".arrow").innerHTML = "&#9660;";
  });
  if (!isActive) {
      element.classList.add("active");
      answer.style.maxHeight = answer.scrollHeight + "px";
      arrow.innerHTML = "&#9650;";
  } else {
      element.classList.remove("active");
      answer.style.maxHeight = null;
      arrow.innerHTML = "&#9660;";
  }
}

document.querySelectorAll(".card-footer_general").forEach((footer) => {
  footer.addEventListener("click", () => {
    const body = footer.previousElementSibling;

    if (body.style.display === "none" || body.style.display === "") {
      document.querySelectorAll(".card-body_general").forEach((b) => {
        b.style.display = "none";
      });
      document.querySelectorAll(".card-footer_general").forEach((f) => {
        f.textContent = "Читати більше";
      });

      body.style.display = "block";
      footer.textContent = "Згорнути";
    } else {
      body.style.display = "none";
      footer.textContent = "Читати більше";
    }
  });
});

