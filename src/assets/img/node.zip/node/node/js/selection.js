const therapists = [
    {
      name: "Ольга",
      therapyType: "self",
      directions: ["trauma", "cbt"],
      city: "kyiv",
      price: 1200,
      format: "online",
      language: "ukrainian",
      gender: "female",
      meetGreeting: true,
    },
  ];
  
  function applyFilters() {
    const form = document.getElementById("filter-form");
    const therapyType = form.querySelector("#therapy-type").value;
    const directions = Array.from(
      form.querySelector("#directions").selectedOptions
    ).map((option) => option.value);
    const city = form.querySelector("#city").value;
    const price = form.querySelector("#price").value;
    const format = form.querySelector("#format").value;
    const language = form.querySelector("#language").value;
    const gender = form.querySelector("#gender").value;
    const meetGreeting = form.querySelector("#meet-greeting").checked;
    const sort = form.querySelector("#sort").value;
    const search = form.querySelector("#search").value.toLowerCase();
  
    let filteredTherapists = therapists;
  
    if (therapyType !== "all") {
      filteredTherapists = filteredTherapists.filter(
        (t) => t.therapyType === therapyType
      );
    }
    if (directions.length > 0) {
      filteredTherapists = filteredTherapists.filter((t) =>
        directions.every((dir) => t.directions.includes(dir))
      );
    }
    if (city !== "all") {
      filteredTherapists = filteredTherapists.filter((t) => t.city === city);
    }
    if (price !== "any") {
      filteredTherapists = filteredTherapists.filter(
        (t) => t.price <= parseInt(price)
      );
    }
    if (format !== "any") {
      filteredTherapists = filteredTherapists.filter((t) => t.format === format);
    }
    if (language !== "any") {
      filteredTherapists = filteredTherapists.filter(
        (t) => t.language === language
      );
    }
    if (gender !== "any") {
      filteredTherapists = filteredTherapists.filter((t) => t.gender === gender);
    }
    if (meetGreeting) {
      filteredTherapists = filteredTherapists.filter((t) => t.meetGreeting);
    }
    if (search) {
      filteredTherapists = filteredTherapists.filter((t) =>
        t.name.toLowerCase().includes(search)
      );
    }
  
    if (sort === "asc") {
      filteredTherapists.sort((a, b) => a.price - b.price);
    } else if (sort === "desc") {
      filteredTherapists.sort((a, b) => b.price - a.price);
    }
  
    displayResults(filteredTherapists);
  }
  
  function displayResults(therapists) {
    const results = document.getElementById("results");
    results.innerHTML = "";
    if (therapists.length === 0) {
      results.innerHTML = "<p>Немає результатів за вашими фільтрами.</p>";
      return;
    }
    therapists.forEach((t) => {
      const therapistDiv = document.createElement("div");
      therapistDiv.className = "therapist";
      therapistDiv.innerHTML = `
              <h2>${t.name}</h2>
              <p>Тип терапії: ${t.therapyType}</p>
              <p>Напрямки: ${t.directions.join(", ")}</p>
              <p>Місто: ${t.city}</p>
              <p>Ціна: ${t.price} грн</p>
              <p>Формат: ${t.format}</p>
              <p>Мова: ${t.language}</p>
              <p>Стать: ${t.gender}</p>
              <p>Зустріч-знайомство: ${t.meetGreeting ? "Так" : "Ні"}</p>
          `;
      results.appendChild(therapistDiv);
    });
  }
  